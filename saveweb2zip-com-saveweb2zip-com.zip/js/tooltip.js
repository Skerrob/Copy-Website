tippy('#tooltip', {
  content: window.isDefaultDownloadTitle,
  placement: 'bottom',
});
tippy('#tooltipSaveStructure', {
  content: window.isSaveStructureTitle,
  placement: 'bottom',
});
